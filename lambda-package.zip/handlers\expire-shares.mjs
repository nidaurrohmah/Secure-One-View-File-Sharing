import { QueryCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { ddb } from "../common/aws.mjs";
import { publishNotification } from "../common/notify.mjs";
import { ok, serverError } from "../common/http.mjs";
import { nowEpoch } from "../common/ids.mjs";

export const handler = async () => {
  try {
    const now = nowEpoch();
    const sharesTable = process.env.SHARES_TABLE || process.env.SHARE_TABLE;
    const result = await ddb.send(new QueryCommand({
      TableName: sharesTable,
      IndexName: "status-expiry-index",
      KeyConditionExpression: "#status = :pending AND expiresAt <= :now",
      ExpressionAttributeNames: { "#status": "status" },
      ExpressionAttributeValues: {
        ":pending": "PENDING",
        ":now": now
      },
      Limit: 50
    }));

    let expired = 0;
    for (const share of result.Items || []) {
      try {
        await ddb.send(new UpdateCommand({
          TableName: sharesTable,
          Key: { shareId: share.shareId },
          UpdateExpression: "SET #status = :expired",
          ConditionExpression: "#status = :pending",
          ExpressionAttributeNames: { "#status": "status" },
          ExpressionAttributeValues: {
            ":pending": "PENDING",
            ":expired": "EXPIRED"
          }
        }));
        expired++;
        await publishNotification(
          "SecureShare: link expired",
          `Link file "${share.fileName}" untuk ${share.recipientEmail} sudah expired.`,
          { type: "FILE_EXPIRED", shareId: share.shareId }
        );
      } catch (error) {
        console.warn("EXPIRE_SHARE_SKIPPED", { shareId: share.shareId, reason: error.name });
      }
    }

    console.log("EXPIRE_SCAN_DONE", { expired });
    return ok({ ok: true, expired });
  } catch (error) {
    return serverError(error);
  }
};
